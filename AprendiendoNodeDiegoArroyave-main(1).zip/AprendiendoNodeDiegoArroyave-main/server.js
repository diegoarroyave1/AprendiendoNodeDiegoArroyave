var http = require("http");


function iniciar(){

    function onRequest(request, response) {
        response.writeHead(200, {"Content-Type": "text/html"});
        response.write("Hola Mundo");
        response.end();

    }

    http.createServer(onRequest).listen(8889);
    console.log("Servidor Iniciado.");
}

exports.iniciar = iniciar;

//mongodb+srv://DiegoArroyave:<password>@cluster0.jqmlrhz.mongodb.net/?retryWrites=true&w=majority