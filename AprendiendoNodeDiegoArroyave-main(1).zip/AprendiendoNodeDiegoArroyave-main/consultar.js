var axios = require('axios');
var data = JSON.stringify({
    "collection": "productos",
    "database": "fakestore",
    "dataSource": "Cluster0",
    "projection": {
        "_id": 1
    }
});
            
var config = {
    method: 'post',
    url: 'https://data.mongodb-api.com/app/data-kgwwm/endpoint/data/v1/action/findOne',
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Request-Headers': '*',
      'api-key': 'vZE2krEjC6C7u2tkaoqOutovqMLH7BpFefgcZ5PQnBZpm7ibfBU4OfrefEyDH3wG',
    },
    data: data
};
            
axios(config)
    .then(function (response) {
        console.log(JSON.stringify(response.data));
    })
    .catch(function (error) {
        console.log(error);
    });
